# Student: Fábio Silva - 1201942

## Developed Tasks

| Sprint | Task                                    |
|--------|-----------------------------------------|
| **B**  | [US 1003](../US1003/US1003.md)          |
| **B**  | [US 1012](../US1012/US1012.md)          |
| **B**  | [US 2001](../us_2001/readme.md)         |
| **B**  | [US 2002](../US2002/US2002.md)          |
| **B**  | [US 2007](../us_2007/readme.md)         |
| **C**  | [US 2004](../us_2004/readme.md)         |
| **C**  | [US 2006](../us_2006/readme.md)         |
| **C**  | [US 3007](../us_3007/readme.md)         |
| **C**  | [US 3010](../us_3010/readme.md)         |
