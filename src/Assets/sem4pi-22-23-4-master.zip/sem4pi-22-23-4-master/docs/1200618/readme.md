# Student: Jorge Cunha 1200618

## Developed Tasks

| Sprint | Task                                                             |
|--------|------------------------------------------------------------------|
| **A**  | US G001 US G002 US G003 US GOO4 US G005 US G006                  |
| **B**  | US 1001 US 1002 US 1009 US 2001 US 2007 US 3003 US 4001  US 5001 |
| **C**  | US 2004 US 3006  US 4002 US 4003 US 5002                         |
