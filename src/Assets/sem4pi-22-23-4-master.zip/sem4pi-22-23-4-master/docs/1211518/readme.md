# Student: Alice Resende - 1211518

## Developed Tasks

| Sprint | Task                                                                                                                                                            |
|--------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **A**  | [US G002](../us_g002/readme.md)                                                                                                                                 |
| **B**  | [US 1008](../us_1001/readme.md)<br/>  [US 2003](../us_2003/readme.md)<br/>  [US 2008](../us_2008/readme.md)<br/>  [US 3001](../us_3001/readme.md) <br/> [US 3002](../us_3002/readme.md) |
| **C**  | [US 3005](../us_3005/readme.md)<br/> [US 2009](../us_2009/readme.md)<br/> [US 3009](../us_3009/readme.md)                                                       |
