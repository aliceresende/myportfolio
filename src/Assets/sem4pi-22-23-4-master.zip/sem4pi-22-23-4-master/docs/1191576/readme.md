# Student: Francisco Sampaio - 1191576

## Developed Tasks

| Sprint | Task                                    |
|--------|-----------------------------------------|
| **A**  | [US G002](../us_g002-EXAMPLE/readme.md) |
| **B**  | [US 1006](us_1006/readme.md)<br/> [US 1007](us_1007/readme.md)<br/> [US 1011](us_1011/readme.md) <br/>[US 2001](us_2001/readme.md) <br/>[US 2007](us_2007/readme.md)<br/> [US 3003](us_3003/readme.md) |
| **C**  | [US 3004](us_3004/readme.md)<br/> [US 3008](us_3008/readme.md)<br/> [US 2005](us_2005/readme.md) <br/>[US 2004](us_2004/readme.md) |
