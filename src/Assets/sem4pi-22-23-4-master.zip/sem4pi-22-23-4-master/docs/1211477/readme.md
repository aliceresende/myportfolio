# Student: Maria Inês Alves - 1211477

## Developed Tasks

| Sprint | Task                                                                                                                                                                                |
|--------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **A**  | US G001 <br/> US G002 <br/>US G003 <br/> US G004 <br/> US G005<br/>US G006                                                                                                          |
| **B**  | [US 1004](../us_1004/readme.md)<br/> [US 1005](../us_1005/readme.md)<br/> [US 1010](../us_1010/readme.md)<br/> [US 2008](../us_2008/readme.md)<br/> [US 3001](../us_4001/readme.md) |
| **C**  | [US 3005](../us_3005/readme.md)<br/> [US 2009](../us_2009/readme.md)<br/> [US 4004](../us_4004/readme.md)                                                                           |
