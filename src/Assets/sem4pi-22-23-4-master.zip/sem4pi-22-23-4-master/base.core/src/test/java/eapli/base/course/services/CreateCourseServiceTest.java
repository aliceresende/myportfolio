package eapli.base.course.services;

import static org.junit.jupiter.api.Assertions.*;

class CreateCourseServiceTest {

}