rm *.class
rm *.token
rm *.tokens
rm *.interp