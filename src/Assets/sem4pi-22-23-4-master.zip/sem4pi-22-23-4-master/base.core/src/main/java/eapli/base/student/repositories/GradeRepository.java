package eapli.base.student.repositories;

import eapli.base.student.domain.Grade;
import eapli.framework.domain.repositories.DomainRepository;

public interface GradeRepository extends DomainRepository<Long, Grade> {
}
