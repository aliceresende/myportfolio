
package eapli.base.schedule.application;


/**
 * The type Schedule controller.
 */
public class ScheduleController {

}
