#ifndef AVERAGESOILHUMIDTY_H
#define AVERAGESOILHUMIDTY_H
char averageSoilHumidity(long readingsPerDay,int linhaDeInicio, int linhaDeFim,char** matrixPtr);
#endif
