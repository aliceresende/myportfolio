#ifndef AVERAGE_H
#define AVERAGE_H
int average(int soma,long readingsPerDay,unsigned short *readings);
#endif