#ifndef LOWEST_H
#define LOWEST_H
int lowest(int lowest,long readingsPerDay,unsigned short *readings);
#endif