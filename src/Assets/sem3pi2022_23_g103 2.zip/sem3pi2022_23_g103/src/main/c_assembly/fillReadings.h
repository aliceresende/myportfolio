void fillReadingsHumSol(int readingsSize, unsigned short* humSolReadingsPtr, unsigned short* pluvioReadingsPtr);
void fillReadingsHumAtm(int readingsSize, unsigned short* humAtmReadingsPtr, unsigned short* pluvioReadingsPtr);
void fillReadingsPluvio(int readingsSize, unsigned short* pluvioReadingsPtr, unsigned short* temperaturaReadingsPtr);
void fillReadingsVelocidadeVento(int readingsSize, unsigned short* velVentoReadingsPtr);
void fillReadingsTemperatura(int readingsSize, unsigned short* temperaturaReadingsPtr);
