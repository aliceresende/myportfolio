#ifndef LOWESTSOILHUMIDITY_H
#define LOWESTSOILHUMIDITY_H
int lowestSoilHumidity( int readingsPerDay, int nSoilSens,int matrix[][readingsPerDay]);
#endif