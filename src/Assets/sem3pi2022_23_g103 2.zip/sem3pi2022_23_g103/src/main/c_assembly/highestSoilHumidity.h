#ifndef HIGHESTSOILHUMIDITY_H
#define HIGHESTSOILHUMIDITY_H
int highestSoilHumidity( int readingsPerDay, int nSoilSens,int matrix[][readingsPerDay]);
#endif