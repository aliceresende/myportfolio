#ifndef ASM_H
#define ASM_H
unsigned int pcg32_random_r(); 
#endif