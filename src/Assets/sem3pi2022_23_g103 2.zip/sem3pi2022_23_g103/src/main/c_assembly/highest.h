#ifndef HIGHEST_H
#define HIGHEST_H
int highest(int highest,long readingsPerDay,unsigned short *readings);
#endif