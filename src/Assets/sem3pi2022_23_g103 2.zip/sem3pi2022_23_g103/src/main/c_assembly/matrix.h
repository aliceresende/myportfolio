#ifndef MATRIX_H
#define MATRIX_H
void createMatrix(int numberOfSensors, int readingsPerDay, int nSoilHum,int matrix[numberOfSensors][readingsPerDay]);
#endif
