package app.utils;

/**
 * The type Validations.
 */
public class Validations {

    private Validations(){}


   /* public static boolean validateRole(String role){
        return role.equals(ROLES.AGRICULTURAL_MANAGER) || role.equals(ROLES.DISTRIBUTION_MANAGER) || role.equals(ROLES.CLIENT) || role.equals(ROLES.DRIVER);
    }

    public static boolean validatePassword(String password){
        String pattern = ".{1,}";
        return password.matches(pattern);
    }*/

}
