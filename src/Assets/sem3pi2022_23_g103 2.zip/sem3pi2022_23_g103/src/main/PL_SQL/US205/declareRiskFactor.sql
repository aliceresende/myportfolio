declare
fatorRisco NUMBER;
begin
fatorRisco := US205ClientRiskFactor(2);
end;